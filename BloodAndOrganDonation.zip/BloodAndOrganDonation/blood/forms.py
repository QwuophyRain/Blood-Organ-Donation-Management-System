from django import forms

from . import models


class BloodForm(forms.ModelForm):
    class Meta:
        model=models.Stock
        fields=['bloodgroup','unit']

class RequestForm(forms.ModelForm):
    class Meta:
        model = models.BloodRequest
        fields = ['patient_name', 'patient_age', 'reason', 'bloodgroup', 'unit']


class OrganForm(forms.ModelForm):
    class Meta:
        model = models.OrganStock
        fields = ['organ', 'amount']

class OrganRequestForm(forms.ModelForm):
    class Meta:
        model = models.OrganRequest
        fields = ['patient_name', 'patient_age', 'reason', 'organ', 'amount']